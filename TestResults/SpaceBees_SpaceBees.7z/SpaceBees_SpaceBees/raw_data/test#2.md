# Details
Tester: User#2
Team Member: jmurphy322
Date/time: 11/20/2022 @ 1:06pm
Relationship bias: friend
Player's game skill: low
Platform: PC with mouse and trackpad
Version: dd1ca1c (76 commits)

# Notes
user could run under the stairs
user said "punching sucks"
user said "where did i come from" at beginning of level
user said "where do i go" after melee bees died
user didn't know to look around during tutorial
user said "camera angles are weird"
user said "i need power ups" while dying
user said "i need health" after taking damage
user said "how do i know if im dying"
user said "can i sneak up behind" refering to the bees on level 2
user said "depth perception is hard to tell when approaching bees"
user said "character needs a dodge ability"
user said "why does the wasp shoot blue balls"

# User Ratings
**user said "comparison was based on real games"**
- After the playtest is complete:
	- "What were your initial impressions after the tutorial?"
	I didn't know it was a tutorial. Updates felt slow and didn't update right away.
	- "What were your impressions during level 1?"
	What was the flower thing? Was it an enemy? Its the same color as the bees so you can't tell if its good or bad. The envoirment looked cool and was nice.
	- "What were your impressions during level 2?"
	It looked the same. COuldn't tell which type of bee. Was it going to shoot or chase? Where's the queen bee? Shouldn't there be a queen trapped in a cage. 
- After the playtest is complete: "Rate the gameplay from low to high on a scale of 1-5 for the following:"
	- "Did the gameplay feel luck based?" 1
	- "Did the gameplay feel skill based?" 3
	- "Does the gameplay feel like a mental challenge?" 1
	- "Does the gameplay feel like a physical challenge?" 1
	- "How clear was the objective at all times?" 3
	- "How fluid was the player movement?" 3
	- "How frustrating was the gameplay?" 3
	- "Were interesting choices provided to the player?" 2
	- "Do the character and controls feel real-time, continuous, and dynamic?" 2
	- "Does the camera movement feel smooth and intuitive?" 2
	- "Does the environment feel interactive?" 3
	- "Does the environment have variety?" 3
	- "How fair does the AI feel as an opponent?" 4 (difficult)
	- "How effective and believable are the AI decisions and animations?" 3
	- "How polished and cohesive does the game feel artistically?" 4
	- "How fun and engaging was the game?" 3
