# Details
Tester: User#4
Team Member: blong34
Date/time: 11/20
Relationship bias: friend
Player's game skill: high
Platform: OSX
Version: Pad

# Notes
What's thumbstick?
More confident with the keyboard and the mouse
Killed the bee almost instantly - "Scared me"
"I'm kinda scared"
punches the first bee - then moved to kicks
Jumps over the bees
"Unsure if I'm still in the tutorial"
Kicks the plant - no idea what it was
Tries to jump on the bees
Trying to jump to move faster
Does not like the loud ass footsteps
Jumped through the door and was like "woah"
"I'm speed running this"
Punching a lot of bees
Found roll by accident
Immidiately started using it and liked it a lot
Was not sure he was close to death
"I did not know I could die"
Restart -> Start naturally
"Oh I got to beat all these people again? Ok I'm ready"
kick is used more
"Kick kinda broken"
Jumped really high a couple of times right at the ledge
Kick feels about how it should - want to make sure I get them
"Oh I missed one - dammit"
Health bar needs to be lower and pointed out
Rolled through the final door and did not trigger credits
-----------------------------
It would be cool if there was a boss
Make the health bar more obvious
Make it clear you are leaving the tutorial
Maybe if it were more like Level 1 and Level 2 - communicate that
Does not know if the suspense adds to it

# User Ratings
- After the playtest is complete:
	- "What were your initial impressions after the tutorial?"
		- Platformer, simple idea, run around and fight some bees
	- "What were your impressions during level 1?"
		- After I beat level 1, I thought it was easy and I would not die
		- Did not know he could die, did not know there is a healthbar
	- "What were your impressions during level 2?"
		- Confused when he glitched through the door
		- Second level felt hard than the first but could not tell because no health bar
- After the playtest is complete: "Rate the gameplay from low to high on a scale of 1-5 for the following:"
	- "Did the gameplay feel luck based?" 2
	- "Did the gameplay feel skill based?" 4
	- "Does the gameplay feel like a mental challenge?" 2
		- 2 because I died, got the process on the second run
		- initial learning curve but after learned it was easy 
	- "Does the gameplay feel like a physical challenge?" 2
	- "How clear was the objective at all times?" 3
	- "How fluid was the player movement?" 3
	- "How frustrating was the gameplay?" 3
		- Died and did not know I could die
		- Had to restart at the beginning
	- "Were interesting choices provided to the player?" 2 
		- Kick, punch, how to attack, I want to roll a lot of jump alot
	- "Do the character and controls feel real-time, continuous, and dynamic?" 4 
	- "Does the camera movement feel smooth and intuitive?"  3
	- "Does the environment feel interactive?" 3
	- "Does the environment have variety?" 4
	- "How fair does the AI feel as an opponent?" 4
	- "How effective and believable are the AI decisions and animations?" 2
	- "How polished and cohesive does the game feel artistically?" 2
	- "How fun and engaging was the game?"  3
