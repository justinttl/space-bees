# Details
Tester: User#1
Team Member: jmurphy322
Date/time: 11/20/2022 @ 12:46pm
Relationship bias: family
Player's game skill: low
Platform: PC with mouse and trackpad
Version: dd1ca1c (76 commits)

# Notes
user found they couldn't turn with mouse pad while running
user found punching useless, always used kick attack
user didn't find jumping useful
user found range attack hard to dodge when missing an attack
user didn't like punching
user couldn't find all the bees since they were too dark
user wasn't clear where to go or what to do
user found the game too short

# User Ratings
- After the playtest is complete:
	- "What were your initial impressions after the tutorial?"
	The popups were in the way and boring. The player and bees are scary.
	- "What were your impressions during level 1?"
	The glowing rocks looks cool. All the lighting was nice but the bees look hidden.
	- "What were your impressions during level 2?"
	The map was so empty and just running around took too long. I felt too slow. Why are the bees just standing there?
- After the playtest is complete: "Rate the gameplay from low to high on a scale of 1-5 for the following:"
	- "Did the gameplay feel luck based?" 2
	- "Did the gameplay feel skill based?" 4
	- "Does the gameplay feel like a mental challenge?" 1
	- "Does the gameplay feel like a physical challenge?" 1
	- "How clear was the objective at all times?" 3
	- "How fluid was the player movement?" 3
	- "How frustrating was the gameplay?" 4
	- "Were interesting choices provided to the player?" 3
	- "Do the character and controls feel real-time, continuous, and dynamic?" 4
	- "Does the camera movement feel smooth and intuitive?" 3
	- "Does the environment feel interactive?" 5
	- "Does the environment have variety?" 5
	- "How fair does the AI feel as an opponent?" 2 (easy)
	- "How effective and believable are the AI decisions and animations?" 4
	- "How polished and cohesive does the game feel artistically?" 5
	- "How fun and engaging was the game?" 3
