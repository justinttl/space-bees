# Details
Tester: User#3
Team Member: Zeke Long (blong34)
Date/time: 11/20 8PM
Relationship bias: family
Player's game skill: low
Platform: Windows
Version: 835743435fad970958132a9172a10dcc3db88197

# Notes
Could not navigate the menus with a controller
Started with the Tutorial from the Menu
Was originally confused with "WASD" or "Thumbstick" -> might need pictures?
Jumped intutively
"I don't know how to kick" -> "Button East" was unclear
Laughed at the Bee the first time
Just mashed at the bee to kill it
@ The start of Level_1, pressed North intuitively and rolled for the first time
Lots of jumping at the bees
Thought the flower was an enemy
"Am I Dying?"
Died and went to restart at the "Start Game" instead of "Start Tutorial"
On the second playthough tried to ignore the ranged bee
Camera is getting stuck on the higher platforms - was not part of the tutorial
Did not know they had to kill the bee -> Need some indication of the goals for the level
*Rolled Through the Door* -> This is a gamebreaking bug
Bees are too dark in the second level, did not see them
Got the ranged bee's timing down with dodging
Upset that they had to fully restart
"Kick is delayed"
"kick is funny"
Mad @ Ranged bee
"Need to be in a better position for the ranged bee"
defaults to kicks as main attack
"Just gonna be a rolly boi"
Fell off platform and thought it was unfair
-----------------------------------------------------
Needs background music
** No Story **, just "go kill bees"
Less Gravity? Was expecting more grand movement
Did not understand level structure -> for level 2 just felt like "You're here now"
Glitched through gate and end of game
Wish there was honey that slowed me down
What was the bee shooting?
Health Bar was not clear - did not know it was there
Would like a character select
Would like to be able to change the colors of the stripes

# User Ratings
- After the playtest is complete:
	- "What were your initial impressions after the tutorial?"
		- Annoying b/c UI was too big and covered the player
		- Also went away too fast, could not finish reading
		- Buttons were confusing
	- "What were your impressions during level 1?"
		- Not much to say, just kills the bees
	- "What were your impressions during level 2?"
		- felt like a boss battle without the boss
		- bees did try to kill me
- After the playtest is complete: "Rate the gameplay from low to high on a scale of 1-5 for the following:"
	- "Did the gameplay feel luck based?" 1
	- "Did the gameplay feel skill based?" 2
	- "Does the gameplay feel like a mental challenge?" 2 
	- "Does the gameplay feel like a physical challenge?" 2 
	- "How clear was the objective at all times?" 2
	- "How fluid was the player movement?" 3
	- "How frustrating was the gameplay?" 3
		- Camera Control was bad
		- Dying by falling off felt bad
		- Dying @ 2nd level should start back at second level
		- No other obstancles except the bees
		- Nothing else to do
	- "Were interesting choices provided to the player?" 1 
	- "Do the character and controls feel real-time, continuous, and dynamic?" 4 
	- "Does the camera movement feel smooth and intuitive?" 3
	- "Does the environment feel interactive?" 1
	- "Does the environment have variety?" 1
	- "How fair does the AI feel as an opponent?" 1
		- It is weak because I can beat it
	- "How effective and believable are the AI decisions and animations?" 3 
	- "How polished and cohesive does the game feel artistically?" Polish - 2, Cohesion - 5
	- "How fun and engaging was the game?" 2
		- Animations were funny

